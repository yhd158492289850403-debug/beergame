declare module '*.png';
